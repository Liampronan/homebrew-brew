//
//  AppDelegate.h
//  PermissionsTest
//
//  Created by Leo Natan (Wix) on 12/9/18.
//  Copyright © 2018 Leo Natan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

